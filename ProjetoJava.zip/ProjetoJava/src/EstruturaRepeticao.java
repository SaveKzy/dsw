import java.util.*;

public class EstruturaRepeticao {

	public static void main(String[] args) {

		while (true) {
			System.out.println(
					"\n===========================================================================================\nDigite o número do exercício desejado (1 a 18) ou 0 (zero) se deseja finalizar o programa.\n===========================================================================================");

			System.out.print("Exercício: ");
			Scanner option = new Scanner(System.in);
			String opcao = option.nextLine();

			if (opcao.equals("1")) {
				ex1();
			} else if (opcao.equals("2")) {
				ex2();
			} else if (opcao.equals("3")) {
				ex3();
			} else if (opcao.equals("4")) {
				ex4();
			} else if (opcao.equals("5")) {
				ex5();
			} else if (opcao.equals("6")) {
				ex6();
			} else if (opcao.equals("7")) {
				ex7();
			} else if (opcao.equals("8")) {
				ex8();
			} else if (opcao.equals("9")) {
				ex9();
			} else if (opcao.equals("10")) {
				ex10();
			} else if (opcao.equals("11")) {
				ex11();
			} else if (opcao.equals("12")) {
				ex12();
			} else if (opcao.equals("13")) {
				ex13();
			} else if (opcao.equals("14")) {
				ex14();
			} else if (opcao.equals("15")) {
				ex15();
			} else if (opcao.equals("16")) {
				ex16();
			} else if (opcao.equals("17")) {
				ex17();
			} else if (opcao.equals("18")) {
				ex18();
			} else if (opcao.equals("0")) {
				break;
			} else {
				System.out.println("\nEntrada inválida.");
			}
		}

		System.out.println(
				"\nFinalizando programa...\n\nObrigado por ter utilizado este programa. Até mais.\n\nPrograma finalizado.");
	}

	private static void ex1() {

		System.out.println("\nSoma de todos os pares entre 1 e 100:");

		int r = 0;

		for (int i = 2; i < 101; i += 2) {
			r += i;
		}

		System.out.println("Essa soma resultará em " + r + ".");

	}

	private static void ex2() {

		System.out.println("\nMédia aritmética dos números entre 13 e 73:");

		double n = 0, m = 0;

		for (int i = 14; i < 73; i++) {

			m++;

			n += i;

		}

		double r = n / m;

		System.out.println("Essa média será de aproximadamente " + Double.toString(r).replace('.', ',') + ".");

	}

	private static void ex3() {

		System.out.print("\nTabuada:\nDigite a tabuada desejada: ");
		Scanner num = new Scanner(System.in);
		String numero = num.nextLine();

		int number = Integer.parseInt(numero);

		for (int i = 1; i < 11; i++) {
			System.out.print(i + " x " + number + " = " + number * i + "\n");
		}

	}

	private static void ex4() {
		System.out.println("\nChico tem 1,50 m e cresce 2 cm ao ano e Ze tem 1,10 m e cresce 3 cm ao ano:\n");

		int chico = 150, ze = 110;

		int t = 0;

		while (ze < chico) {

			t++;

			chico += 2;
			ze += 3;

		}

		double zeOut = (double) ze / 100;
		double chicoOut = (double) chico / 100;

		System.out.println("É preciso " + t + " anos para Ze ter " + zeOut + "m e Chico ter " + chicoOut + "m.");

	}

	private static void ex5() {
		Scanner s = new Scanner(System.in);
		double numero1, numero2, resultado;

		while (true) {
			System.out.print("\nDivisor (Digite um número negativo para encerrar o código): \n");
			System.out.print("\nDigite o primeiro número (positivo): ");
			numero1 = s.nextDouble();
			if (numero1 < 0) {
				break;
			}
			System.out.print("Digite o segundo número (positivo): ");
			numero2 = s.nextDouble();
			if (numero2 < 0) {
				break;
			}
			if (numero2 != 0) {
				resultado = (double) numero1 / numero2;
				System.out.println("Resultado da divisão: " + resultado);
			} else {
				System.out.println("Não há divisão por zero.");
			}
		}

		System.out.println("Fim do programa.");
	}

	private static void ex6() {

		System.out.println("\nCorrida de automoveis:\n");
		Scanner scan_volta = new Scanner(System.in);

		double melhor = 0;
		double voltas = 0;
		int melhor_volta = 0;

		for (int i = 0; i < 10; i++) {

			System.out.print("Volta " + (i + 1) + ": ");

			double volta = scan_volta.nextDouble();

			voltas += volta;

			if (i == 0 || melhor > volta) {

				melhor = volta;

				melhor_volta = i + 1;

			}

		}

		double media = voltas / 10;

		System.out.println("\nMelhor tempo: " + melhor + ";\nVolta de melhor tempo: " + melhor_volta + ";\nMédia: "
				+ media + ".\n");

	}

	private static void ex7() {
		Scanner sc = new Scanner(System.in);
		int idade, contPesoAltura = 0, contIdade = 0;
		double peso, altura, media = 0;
		int contMais190 = 0, contIdadeMais190 = 0;

		for (int i = 1; i <= 10; i++) {
			System.out.println("\nDigite os dados da " + i + "ª pessoa:");
			System.out.print("Idade: ");
			idade = sc.nextInt();
			media += idade;

			System.out.print("Peso (em kg): ");
			peso = sc.nextDouble();

			System.out.print("Altura (em metros): ");
			altura = sc.nextDouble();

			if (peso > 90 && altura < 1.5) {
				contPesoAltura++;
			}

			if (altura > 1.9) {
				contMais190++;
				if (idade >= 10 && idade <= 30) {
					contIdadeMais190++;
				}
			}
		}

		media /= 10;
		double percIdadeMais190 = (double) contIdadeMais190 / contMais190 * 100;

		System.out.println("\nMédia das idades: " + media);
		System.out.println(
				"Quantidade de pessoas com peso superior a 90 kg e altura inferior a 1,50 m: " + contPesoAltura);
		System.out.printf(
				"Percentagem de pessoas com idade entre 10 e 30 anos entre as pessoas que medem mais de 1,90 m: %.2f%%\n",
				percIdadeMais190);
	}

	private static void ex8() {
		Scanner N = new Scanner(System.in);
		double prova = 0;
		double maiorNota = 0;
		double menorNota = Double.MAX_VALUE;

		while (true) {
			System.out.print("\nDigite a nota do aluno (-1 para encerrar): ");
			double nota = N.nextDouble();

			if (nota < 0) {
				break;
			}

			prova++;
			if (nota > maiorNota) {
				maiorNota = nota;
			}
			if (nota < menorNota) {
				menorNota = nota;
			}
		}

		System.out.println("\nNúmero de alunos: " + prova);
		System.out.println("Maior nota: " + maiorNota);
		if (menorNota == Double.MAX_VALUE) {
			System.out.println("Menor nota: 0");
		} else {
			System.out.println("Menor nota: " + menorNota);
		}
	}

	private static void ex9() {
		Scanner V = new Scanner(System.in);
		int n6 = 0;
		int i4M6 = 0;
		int M4 = 0;

		while (true) {
			System.out.print("\nDigite a nota do aluno (-1 para encerrar): ");
			double nota = V.nextDouble();

			if (nota < 0) {
				break;
			}

			if (nota >= 6.0) {
				n6++;
			} else if (nota >= 4.0) {
				i4M6++;
			} else {
				M4++;
			}
		}

		System.out.println("\nNotas maiores ou iguais a 6.0: " + n6);
		System.out.println("Notas maiores ou iguais a 4.0 e menores que 6.0: " + i4M6);
		System.out.println("Quantidade de notas menores que 4.0: " + M4);
	}

	private static void ex10() {

		Random random = new Random();

		Scanner input = new Scanner(System.in);

		System.out.println("\nSorteio de números (1 - 100):\n(digite '-1' para finalizar o programa)\n");

		int pontos = 0;

		boolean t = true;

		while (t) {

			int sorteio = random.nextInt(101);

			while (t) {

				int entrada = input.nextInt();
				if (entrada < -1) {
					System.out.println("Entrada inválida, por favor digite um número entre 0 e 100 ou -1 para sair.");
				} else if (entrada == -1) {
					t = false;
					break;
				} else if (entrada > sorteio) {
					System.out.println("Número incorreto, tente um valor menor.");
				} else if (entrada < sorteio) {
					System.out.println("Número incorreto, tente um valor maior.");
				} else if (entrada == sorteio) {
					System.out.println("Número correto!\n\nPróximo jogo iniciado('-1' para finalizar):");
					pontos++;
					break;
				}

			}
		}

		System.out.print("\nO total de pontos foi: " + pontos + ".\n");

	}

	private static void ex11() {

		Scanner scanA = new Scanner(System.in);
		Scanner scanB = new Scanner(System.in);
		Scanner equacao = new Scanner(System.in);

		System.out.print(
				"\nCalculadora quebrada:\n(esse programa fornece ambas multiplicação e divisão inteira)\n\nDigite o primeiro número: ");

		int a = scanA.nextInt();

		System.out.print("Digite o segundo número: ");

		int b = scanB.nextInt();

		int multiplicacao = 0;

		boolean negativo = false;

		if (b < 0) {
			b *= -1;
			negativo = true;
		}

		for (int i = 0; i < b; i++) {
			multiplicacao += a;
		}

		boolean zero = false;

		int divisao = 0;

		boolean negativoA = false;

		int falseA = a;

		if (a < 0) {
			falseA *= -1;
			negativoA = true;
		}

		if (b == 0) {
			zero = true;
		} else {
			while (falseA >= b) {
				divisao++;
				falseA -= b;
			}
		}

		if (negativo) {
			b *= -1;
			multiplicacao *= -1;
			divisao *= -1;
		}
		if (negativoA) {
			divisao *= -1;
		}

		System.out.println("\nMultiplicação: " + a + " * " + b + " = " + multiplicacao);

		if (zero) {
			System.out.println("\nNão possível fazer divisão por zero.");
		} else {
			System.out.println("Divisão: " + a + " / " + b + " = " + divisao);
		}
	}

	private static void ex12() {

		Scanner scanPrimo = new Scanner(System.in);

		System.out.print("\nVerificador de primo:\nDigite o número que deseja verificar: ");

		int primo = scanPrimo.nextInt();

		boolean t = true;

		if (primo <= 1) {
			System.out.print("Entrada inválida.");
		} else if (primo % 2 == 0) {

			System.out.println(primo + " não é um número primo. Ele é divisivel por 2.\n");
			t = false;

		} else {

			for (int i = 3; i < primo; i += 2) {

				if (primo % i == 0) {

					System.out.println(primo + " não é um número primo. Ele é divisivel por " + i + ".\n");
					t = false;
					break;

				}

			}

		}

		if (t) {

			System.out.println(primo + " é um número primo.");

		}

	}

	private static void ex13() {

		System.out.print("\nCalculadora da área de um triângulo:\n");

		Scanner valScan1 = new Scanner(System.in);
		Scanner valScan2 = new Scanner(System.in);
		System.out.print("Digite valor do 1° lado: ");
		double val1 = valScan1.nextDouble();
		System.out.print("Digite valor do 2° lado: ");
		double val2 = valScan2.nextDouble();
		double x = (val2 * -1) / val1;
		double Area = val1 * val2 / 2;
		System.out.println("A área do triângulo é " + Area + "m².");

	}

	private static void ex14() {

		Scanner inputScan = new Scanner(System.in);

		System.out.print(
				"\nS = 1/1 + 2/3 + 3/5 + ... + n/m:\n(Esse programa fornece uma aproximação)\nDigite o valor de n: ");

		int input = inputScan.nextInt();

		double result = 1;

		System.out.print("\nS = 1/1");

		for (double i1 = 2, i2 = 3; i1 < input + 1; i1++, i2 += 2) {

			System.out.print(" + " + (int) i1 + "/" + (int) i2);

			result += i1 / i2;
		}

		System.out.print(" = " + result + ".\n");

	}

	private static void ex15() {
		Scanner s = new Scanner(System.in);
		System.out.print("\nFatorial:\nDigite um número inteiro: ");
		int n = s.nextInt();

		int fatorial = 1;
		for (int i = 2; i <= n; i++) {
			fatorial *= i;
		}

		System.out.println(n + "! = " + fatorial);
	}

	private static void ex16() {
		Scanner c = new Scanner(System.in);
		System.out.print("\nQuantidade de divisores:\nDigite um número inteiro positivo: ");
		int n = c.nextInt();

		int Divi = 0;
		for (int i = 1; i <= n; i++) {
			if (n % i == 0) {
				Divi++;
			}
		}

		System.out.println("O número " + n + " tem " + Divi + " divisores.");
	}

	private static void ex17() {
		Scanner h = new Scanner(System.in);

		System.out.print(
				"\n(Há um limite no valor de 2147483647 por conta do tipo int em java)\nN primeiros números da Sequência de Fibonacci:\nDigite o valor de N: ");
		int n = h.nextInt();

		int a = 1, b = 1, c;

		System.out.print("Sequência de Fibonacci até o " + n + "º termo: 0");

		for (int i = 2; i <= n; i++) {
			System.out.print(", " + a);
			c = a + b;
			a = b;
			b = c;
		}

		System.out.print(".\n");

	}

	private static void ex18() {
		Scanner J = new Scanner(System.in);
		int FUNCOpcao1 = 0;
		int FUNCOpcao2 = 0;
		int SemAumento = 0;
		double Antes = 0;
		double Depois = 0;

		while (true) {
			System.out.print(
					"\nAumento salarial diferenciado:\nDigite o cargo do funcionario (digite 'vazio' para encerrar): ");
			String cargo = J.nextLine();
			if (cargo.equals("vazio")) {
				break;
			}
			System.out.print("Digite os anos de trabalho do funcionario: ");
			int tempoServico = J.nextInt();
			J.nextLine();
			System.out.print("Digite o salário atual: ");
			double salarioAtual = J.nextDouble();
			J.nextLine();
			System.out.print("Digite o número de filhos: ");
			int numFilhos = J.nextInt();
			J.nextLine();

			double aumento = 0.0;

			if ((numFilhos >= 1 && numFilhos <= 3) && (tempoServico >= 10) &&
					(cargo.equals("Administrativo I") || cargo.equals("Administrativo II"))) {
				aumento = 0.0525 + (0.005 * tempoServico);
				FUNCOpcao1++;
			} else if ((numFilhos > 3) && (cargo.equals("Administrativo II") || cargo.equals("Administrativo III"))) {
				aumento = 0.0575 + (0.006 * tempoServico);
				FUNCOpcao2++;
			} else {
				SemAumento++;
			}

			double novoSalario = salarioAtual * (1 + aumento);
			Antes += salarioAtual;
			Depois += novoSalario;

			System.out.println("\nSalario atual: R$" + salarioAtual);
			System.out.println("Novo salario: R$" + novoSalario);
			System.out.println("Aumento: " + (aumento * 100) + "%");

		}

		System.out.println("Total da folha de pagamento antes : R$" + Antes);
		System.out.println("Total da folha de pagamento depois: R$" + Depois);
		System.out.println("Quantidade de funcionarios da primeira opção: " + FUNCOpcao1);
		System.out.println("Quantidade de funcionarios da segunda opção: " + FUNCOpcao2);
		System.out.println("Quantidade de funcionarios sem aumento: " + SemAumento);
	}

}